@import Foundation;

//! Project version number for MatomoTracker.
FOUNDATION_EXPORT double MatomoTrackerVersionNumber;

//! Project version string for MatomoTracker.
FOUNDATION_EXPORT const unsigned char MatomoTrackerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MatomoTracker/PublicHeader.h>


